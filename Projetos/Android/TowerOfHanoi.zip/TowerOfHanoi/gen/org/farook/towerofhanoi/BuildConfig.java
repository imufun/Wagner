/** Automatically generated file. DO NOT MODIFY */
package org.farook.towerofhanoi;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}